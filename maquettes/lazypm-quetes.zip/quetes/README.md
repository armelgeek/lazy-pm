# Les 30 quêtes de LazyPM

Le plan pour construire LazyPM en vibe codant avec Claude Code, en suivant la méthode LazyPM.

## Comment s'en servir
1. Crée le projet et copie les maquettes dedans, dans un dossier `maquettes/`.
2. Copie `00-contexte-CLAUDE.md` à la racine du projet sous le nom `CLAUDE.md`. C'est pour Claude : tu n'as pas besoin de le lire.
3. Chaque soir : ouvre ta quête, prépare ce qu'il te faut, colle le prompt dans Claude Code, puis teste chaque cas de la checklist comme un utilisateur.
4. Fais ton check-in, et publie-le dans le journal.

## Section 1 · Faire marcher le truc (#01 → #06)
Ton site en ligne, des gens qui en veulent, et le cœur du produit qui marche : une idée devient un plan de 30 quêtes.

- [#01 · Le site existe](quete-01.md) · environ 1 à 2 h
- [#02 · Des gens en veulent](quete-02.md) · environ 2 h, sur 2 jours
- [#03 · Le briefing marche](quete-03.md) · environ 2 à 3 h
- [#04 · L'IA génère le plan](quete-04.md) · **boss** · environ 3 à 4 h
- [#05 · Comptes et page de quête](quete-05.md) · environ 3 h
- [#06 · Tester pour de vrai](quete-06.md) · environ 2 à 3 h

## Section 2 · Se faire payer (#07 → #14)
Encaisser, protéger tes crédits IA, faire revenir les gens chaque soir, et ton tout premier client.

- [#07 · Brancher les paiements](quete-07.md) · environ 2 à 3 h
- [#08 · Le mur de la #04](quete-08.md) · environ 2 h
- [#09 · Le check-in du soir](quete-09.md) · environ 2 à 3 h
- [#10 · Les pages légales](quete-10.md) · environ 2 h
- [#11 · Ton premier client](quete-11.md) · **boss** · environ 2 h, plus des messages
- [#12 · Plus tard et quêtes bonus](quete-12.md) · environ 2 à 3 h
- [#13 · Le copilote « je suis bloqué »](quete-13.md) · environ 3 h
- [#14 · Le compte](quete-14.md) · environ 2 h

## Section 3 · Préparer le lancement (#15 → #21)
Les emails qui ramènent, le journal public, la sécurité, et le jour où tu le montres au monde.

- [#15 · Les emails qui ramènent](quete-15.md) · environ 2 h
- [#16 · Le journal public](quete-16.md) · environ 2 h
- [#17 · Sécurité et limites de coût](quete-17.md) · environ 3 h
- [#18 · Le replanning](quete-18.md) · environ 2 h
- [#19 · Le lancement public](quete-19.md) · **boss** · environ une soirée, plus la journée
- [#20 · Mesurer ce qui compte](quete-20.md) · environ 2 h
- [#21 · Répondre vite](quete-21.md) · environ 1 à 2 h

## Section 4 · Écouter et ajuster (#22 → #30)
Ce que tes clients demandent, ce qui les fait partir, et la suite.

- [#22 · Écrire à chaque client](quete-22.md) · environ 1 h, plus les messages
- [#23 · Ranger les retours](quete-23.md) · environ 2 à 3 h
- [#24 · Le pass saison et plusieurs projets](quete-24.md) · environ 3 à 4 h
- [#25 · Réduire l'abandon](quete-25.md) · environ 2 h
- [#26 · Sans boss : tu écoutes](quete-26.md) · environ 2 h, sans code
- [#27 · Que les utilisateurs partagent](quete-27.md) · environ 2 h
- [#28 · La saison 2 se prépare](quete-28.md) · environ 1 à 2 h
- [#29 · Livrer la demande n°1](quete-29.md) · environ 4 à 6 h
- [#30 · Le bilan de saison](quete-30.md) · environ 2 h
