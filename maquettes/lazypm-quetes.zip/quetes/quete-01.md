# Quête #01 · Le site existe

Section 1 · Faire marcher le truc · environ 1 à 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** La page d'accueil de LazyPM en ligne sur ton adresse, avec un champ où les gens laissent leur idée et leur email.

**Test :** Tu ouvres ton adresse sur ton téléphone, tu laisses un email, et tu le retrouves dans ta liste.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **TÉLÉPHONE** · La page ouverte sur un vrai téléphone → lisible, rien ne dépasse sur le côté
- [ ] **DOUBLON** · Le même email envoyé deux fois → une seule personne dans la liste
- [ ] **FAUTE** · Un email sans @ → un message clair, rien n'est enregistré
- [ ] **ADRESSE** · Ton adresse tapée sans « www » → la page s'ouvre quand même, avec le cadenas

## Le piège d'expérience
Vouloir tout construire ce soir. Seule la page d'accueil compte : le reste attendra sa quête.

## Ce qu'il te faut
- Un nom de domaine (environ 12 $ par an)
- Les maquettes copiées dans le projet, dans un dossier maquettes/

## Le prompt à coller dans Claude Code

```text
# QUÊTE #01 : LE SITE EXISTE
Crée le site de LazyPM et mets-le en ligne.

// 1. Ce que je veux obtenir :
- La page d'accueil exactement comme la maquette maquettes/index.html : mêmes couleurs, mêmes polices, mêmes espacements
- Le champ « ton idée » et le formulaire de la liste des fondateurs gardent l'idée et l'email dans une liste que je peux consulter
- Le site en ligne sur mon adresse lazypm.app

// 2. Les cas que tu dois obligatoirement gérer :
- Le même email deux fois : une seule entrée, on met juste l'idée à jour
- Un email mal écrit : un message clair, rien n'est gardé
- Personne d'autre que moi ne peut lire la liste des emails
- La page doit être parfaite sur téléphone

// 3. Explication pas à pas :
Ensuite, explique-moi ce que je dois faire de mon côté pour brancher mon adresse et voir la liste des emails. En français simple, sans jargon.
```

## Hors code
- [ ] Acheter ton adresse
- [ ] Écrire ta première entrée du journal, même à la main
