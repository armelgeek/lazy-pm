# Quête #02 · Des gens en veulent

Section 1 · Faire marcher le truc · environ 2 h, sur 2 jours · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Chaque inscrit reçoit un email de bienvenue, et toi tu vois qui s'inscrit, d'où il vient, et quelle idée il a en pause.

**Test :** Tu t'inscris avec un autre email : le message arrive en moins d'une minute, et tu te vois dans ta page de suivi.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **SPAMS** · L'email de bienvenue → dans la boîte principale, pas dans les spams
- [ ] **ORIGINE** · Un lien partagé sur X → tu sais que la personne vient de X
- [ ] **PRIVÉ** · Ta page de suivi ouverte sans le mot de passe → accès refusé
- [ ] **RÉPONSE** · Quelqu'un répond à l'email de bienvenue → la réponse arrive dans ta vraie boîte

## Le piège d'expérience
Montrer la page à des gens qui veulent te faire plaisir. Choisis des gens qui ont vraiment 3 projets en pause, et écoute ce qu'ils ne disent pas.

## Ce qu'il te faut
- Une liste de 10 personnes qui construisent avec l'IA
- Un service d'envoi d'emails (gratuit au début), avec ton adresse vérifiée pour ne pas tomber dans les spams

## Le prompt à coller dans Claude Code

```text
# QUÊTE #02 : DES GENS EN VEULENT
Je veux savoir si des gens veulent vraiment LazyPM.

// 1. Ce que je veux obtenir :
- Un email de bienvenue court, signé de mon prénom, qui demande à la personne de répondre avec l'idée qu'elle a en pause
- Une page de suivi, protégée par un mot de passe que je choisis (les comptes n'existent pas encore), avec la liste des inscrits, leur idée, d'où ils viennent, et le total de la semaine
- Savoir d'où vient chaque inscrit (X, LinkedIn, un ami) grâce au lien que je partage

// 2. Les cas que tu dois obligatoirement gérer :
- Personne d'autre que moi ne peut ouvrir la page de suivi
- L'email ne doit pas tomber dans les spams
- Le texte de l'email doit être facile à modifier pour moi

// 3. Explication pas à pas :
Ensuite, explique-moi comment créer un lien différent pour chaque endroit où je partage le site. En français simple, sans jargon.
```

## Hors code
- [ ] Envoyer le lien à 10 personnes, un message personnel à chacune
- [ ] Noter ce qu'elles demandent spontanément
- [ ] Publier ton premier post du soir
