# Quête #10 · Les pages légales

Section 2 · Se faire payer · environ 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Les pages Conditions, Confidentialité et Remboursements, avant d'encaisser de vrais paiements : Stripe les demande, et elles disent la vérité sur ce que LazyPM fait des données.

**Test :** Tu cliques sur chaque lien du bas de page : aucun ne mène nulle part, et chaque page est lisible.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **VÉRITÉ** · Chaque donnée citée → existe vraiment dans LazyPM
- [ ] **IA** · La page Confidentialité → dit ce qui est envoyé à l'IA
- [ ] **LIENS** · Tous les liens du site → aucun ne mène nulle part
- [ ] **PAIEMENT** · La page de paiement → mène aux conditions

## Le piège d'expérience
Les repousser au lancement. Stripe les demande pour activer les vrais paiements, et ton premier client arrive à la #11. Et ne copie pas celles d'un autre site : elles décrivent son produit, pas le tien.

## Ce qu'il te faut
- Les informations de ta société (HAYZAR LLC)

## Le prompt à coller dans Claude Code

```text
# QUÊTE #10 : LES PAGES LÉGALES
Je veux les pages légales de LazyPM.

// 1. Ce que je veux obtenir :
- Trois pages : Conditions, Confidentialité, Remboursements, dans le style du site
- Un premier jet en français simple, écrit à partir de ce que LazyPM fait vraiment : les données gardées, ce qui est envoyé à l'IA, combien de temps, comment tout supprimer
- La garantie du pass saison (il arrivera à la quête #24) : remboursé si le client n'a rien lancé à sa quête #30 ou au bout de 12 mois
- Les liens dans le bas de page, à l'inscription et au paiement

// 2. Les cas que tu dois obligatoirement gérer :
- Marquer clairement les passages à faire relire par quelqu'un de compétent
- Supprimer ou remplacer tous les liens qui ne mènent nulle part

// 3. Explication pas à pas :
Ensuite, explique-moi ce que je dois absolument faire relire. En français simple, sans jargon.
```

## Hors code
- [ ] Faire relire les trois pages avant d'encaisser ton premier client
