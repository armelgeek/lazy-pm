# Quête #11 · Ton premier client · BOSS

Section 2 · Se faire payer · environ 2 h, plus des messages · +50 XP

## 01 · Le résultat & le test de vérité
**À construire :** Le paiement s'ouvre pour ta liste des fondateurs. Chacun reçoit un lien personnel pour payer 5 $ par mois à vie.

**Test :** Une vraie personne paie avec une vraie carte, et accède tout de suite à la quête #04.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **RELECTURE** · L'email aux fondateurs → tu le reçois d'abord toi-même pour le relire
- [ ] **EXPIRÉ** · Un lien personnel utilisé après 7 jours → un message clair
- [ ] **ACCÈS** · Juste après le paiement → les quêtes #04 et suivantes s'ouvrent
- [ ] **MERCI** · Après le paiement → une page de remerciement et un email de bienvenue

## Le piège d'expérience
Attendre que le produit soit fini pour demander de l'argent. Ton premier client paie pour la promesse et pour toi, pas pour la quête #30.

## Ce qu'il te faut
- Ta liste des fondateurs
- Ton compte Stripe validé

## Le prompt à coller dans Claude Code

```text
# QUÊTE #11 : TON PREMIER CLIENT
J'ouvre le paiement à ma liste des fondateurs.

// 1. Ce que je veux obtenir :
- Passer les paiements en « vrai argent », sans casser les tests
- Un lien de paiement personnel pour chaque personne de la liste, au prix fondateur, valable 7 jours
- Un email court et personnel à la liste qui annonce l'ouverture
- Une page de remerciement et un email de bienvenue qui dit quoi faire ce soir
- Dans ma page de suivi : qui a payé, et le total par mois

// 2. Les cas que tu dois obligatoirement gérer :
- Pouvoir m'envoyer l'email à moi seul avant de l'envoyer à tout le monde
- Le texte de l'email doit être facile à modifier
- Personne ne doit être prélevé deux fois

// 3. Explication pas à pas :
Ensuite, explique-moi exactement quoi vérifier avant d'envoyer l'email à toute la liste. En français simple, sans jargon.
```

## Hors code
- [ ] Écrire un message personnel aux 5 fondateurs les plus actifs
- [ ] Appeler ton premier client pour lui demander pourquoi il a payé
- [ ] Post « premier client », avec son accord
