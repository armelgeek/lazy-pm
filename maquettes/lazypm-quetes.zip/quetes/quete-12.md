# Quête #12 · Plus tard et quêtes bonus

Section 2 · Se faire payer · environ 2 à 3 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Une page pour noter une idée sans dérailler. Pour ce qui casse, « Réparer maintenant » donne un prompt prêt à coller.

**Test :** Tu notes « le bouton copier marche pas sur Safari », tu cliques « Réparer maintenant » : tu obtiens un prompt et 3 choses à vérifier.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **ORIGINE** · Une note prise pendant la #05 → elle garde « noté pendant #05 »
- [ ] **COLLAGE** · Un texte collé avec des balises bizarres → affiché tel quel, sans rien casser
- [ ] **IDÉE** · Une idée (pas un bug) → pas de « Réparer maintenant », elle attend le tri
- [ ] **RÉPARÉ** · « C'est réparé » → la note disparaît, le plan ne bouge pas

## Le piège d'expérience
Proposer « Réparer maintenant » pour les idées aussi. Une idée attend le tri de la #22, sinon on déraille.

## Ce qu'il te faut
- La maquette maquettes/plus-tard.html

## Le prompt à coller dans Claude Code

```text
# QUÊTE #12 : PLUS TARD ET QUÊTES BONUS
Je veux la page Plus tard de LazyPM.

// 1. Ce que je veux obtenir :
- La page comme maquettes/plus-tard.html
- On note une idée, une chose à réparer, ou la réponse d'un client (avec qui, et s'il a annulé)
- Des filtres « Tout », « À réparer », « Idées » avec les compteurs
- « Réparer maintenant » ouvre un panneau avec un prompt écrit par l'IA et 3 choses à vérifier, adaptés à l'outil de la personne

// 2. Les cas que tu dois obligatoirement gérer :
- Chaque note garde la quête pendant laquelle elle a été prise
- La quête bonus ne donne pas d'XP et ne change pas le plan
- Elle respecte le mur de la #04
- Le chiffre à côté de « Plus tard » dans le menu est toujours juste

// 3. Explication pas à pas :
Ensuite, explique-moi comment l'IA choisit ce qu'elle met dans le prompt de réparation. En français simple, sans jargon.
```
