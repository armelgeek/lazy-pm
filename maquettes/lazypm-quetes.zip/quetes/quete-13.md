# Quête #13 · Le copilote « je suis bloqué »

Section 2 · Se faire payer · environ 3 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Dans une quête, un bouton ouvre une aide qui connaît déjà le projet, la quête et ce qui a été fait.

**Test :** Tu écris « le bouton passe sous le clavier sur iPhone » : le copilote répond en parlant de ta quête, et propose une seule chose à essayer.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **CONTEXTE** · Une question vague → le copilote parle quand même de la bonne quête
- [ ] **UNE CHOSE** · Un vrai blocage → une piste à la fois, pas un roman
- [ ] **GRATUIT** · Un compte gratuit → pas de copilote, même en bidouillant
- [ ] **LIMITE** · Beaucoup de messages dans la journée → un message clair après la limite

## Le piège d'expérience
Renvoyer toute la conversation et tout le projet à chaque message. Le coût explose en une semaine.

## Ce qu'il te faut
- La maquette maquettes/quete.html (panneau « Je suis bloqué »)

## Le prompt à coller dans Claude Code

```text
# QUÊTE #13 : LE COPILOTE « JE SUIS BLOQUÉ »
Je veux le copilote « Je suis bloqué » de LazyPM.

// 1. Ce que je veux obtenir :
- Un panneau d'aide dans la page de quête, comme dans maquettes/quete.html
- Le copilote connaît l'idée, l'outil utilisé, la quête en cours, les objectifs pas encore cochés et les 3 derniers check-ins
- Il répond au fil de l'eau, en français simple, une piste à la fois, et donne un prompt à coller quand c'est utile

// 2. Les cas que tu dois obligatoirement gérer :
- Réservé aux abonnés, impossible à contourner
- Une limite de messages par jour et un budget par mois et par personne
- Garder le contexte court pour que chaque message coûte peu

// 3. Explication pas à pas :
Ensuite, explique-moi combien coûte en moyenne une conversation, et comment le voir. En français simple, sans jargon.
```

## Dans ton journal
À partir de cette quête, LazyPM fait pour toi : le copilote « je suis bloqué ».
