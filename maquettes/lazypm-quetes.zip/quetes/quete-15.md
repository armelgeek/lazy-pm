# Quête #15 · Les emails qui ramènent

Section 3 · Préparer le lancement · environ 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Un rappel le soir pour le check-in et un résumé le dimanche, à la bonne heure pour chacun, faciles à couper.

**Test :** Tu règles ton rappel à 22 h : il arrive à 22 h, et pas si tu as déjà fait ton check-in.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **DÉJÀ FAIT** · Check-in déjà fait → pas de rappel ce soir
- [ ] **FUSEAU** · Un utilisateur à Dakar → rappel à 22 h chez lui
- [ ] **DÉSABONNER** · Le lien « ne plus recevoir » → marche sans se connecter
- [ ] **DOUBLE** · Un bug d'envoi relancé → personne ne reçoit deux fois le même email

## Le piège d'expérience
Envoyer le rappel à tout le monde à 22 h heure de Paris. Le fuseau de chacun compte dès le début.

## Le prompt à coller dans Claude Code

```text
# QUÊTE #15 : LES EMAILS QUI RAMÈNENT
Je veux les emails qui font revenir les gens sur LazyPM.

// 1. Ce que je veux obtenir :
- Un rappel à l'heure choisie (22 h par défaut) avec la quête du soir, la série, et un lien direct vers la quête
- Le dimanche matin, un résumé de la semaine : quêtes faites, série, date de lancement
- Un lien « ne plus recevoir » dans chaque email

// 2. Les cas que tu dois obligatoirement gérer :
- Pas de rappel si le check-in est déjà fait
- Chaque personne reçoit ses emails à l'heure de chez elle
- Jamais deux fois le même email

// 3. Explication pas à pas :
Ensuite, explique-moi comment vérifier que les emails partent bien chaque soir. En français simple, sans jargon.
```
