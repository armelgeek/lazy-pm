# Quête #16 · Le journal public

Section 3 · Préparer le lancement · environ 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Ton build in public se publie tout seul : chaque check-in que tu coches « public » devient une entrée du journal.

**Test :** Tu fais ton check-in, tu coches « publier » : il apparaît sur ta page journal dans la minute.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **PRIVÉ** · Un check-in non coché → n'apparaît jamais
- [ ] **PARTAGE** · Le lien du journal collé sur X → un aperçu avec ta progression
- [ ] **SUIVRE** · Quelqu'un suit le journal → il reçoit une confirmation
- [ ] **VITESSE** · La page ouverte sur un téléphone en 4G → rapide

## Le piège d'expérience
Retoucher une ancienne entrée pour qu'elle paraisse meilleure. Le journal ne vaut que parce qu'il n'est jamais retouché.

## Ce qu'il te faut
- La maquette maquettes/journal.html

## Le prompt à coller dans Claude Code

```text
# QUÊTE #16 : LE JOURNAL PUBLIC
Je veux le journal public de LazyPM.

// 1. Ce que je veux obtenir :
- La page comme maquettes/journal.html
- Une case « publier dans le journal » dans mon check-in (visible seulement pour moi)
- Le journal affiche mes check-ins publics, du plus récent au plus ancien, avec ma progression
- L'encart « Ce que LazyPM fait déjà pour moi », que je peux mettre à jour facilement
- « Suivre le journal » : on laisse son email et on reçoit une confirmation

// 2. Les cas que tu dois obligatoirement gérer :
- Rien de privé ne doit jamais apparaître
- Un joli aperçu quand on partage le lien
- Seul moi peux publier

// 3. Explication pas à pas :
Ensuite, explique-moi comment mettre à jour l'encart « Ce que LazyPM fait déjà pour moi ». En français simple, sans jargon.
```

## Hors code
- [ ] Mettre le lien du journal dans ta bio X et LinkedIn
