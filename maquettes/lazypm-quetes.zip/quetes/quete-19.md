# Quête #19 · Le lancement public · BOSS

Section 3 · Préparer le lancement · environ une soirée, plus la journée · +50 XP

## 01 · Le résultat & le test de vérité
**À construire :** LazyPM s'ouvre à tout le monde avec une seule formule, l'abonnement à 9 $ par mois, et ton annonce partout.

**Test :** Un inconnu arrive, s'abonne à 9 $ par mois, et ouvre la quête #04. Un fondateur, lui, paie toujours 5 $.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **UNE FORMULE** · La page d'accueil → une seule formule payante, le pass saison annoncé « bientôt »
- [ ] **FONDATEURS** · Un fondateur → garde son prix à vie
- [ ] **VITESSE** · La page d'accueil sur un téléphone en 4G → rapide
- [ ] **JOUR J** · Un problème le jour du lancement → tu le vois tout de suite

## Le piège d'expérience
Lancer avec trop de formules, ou un vendredi soir. Une seule formule, un mardi ou un mercredi matin, et ta journée bloquée pour répondre.

## Ce qu'il te faut
- Les maquettes index-lancement.html et paywall-lancement.html

## Le prompt à coller dans Claude Code

```text
# QUÊTE #19 : LE LANCEMENT PUBLIC
C'est le lancement public de LazyPM.

// 1. Ce que je veux obtenir :
- La page d'accueil de lancement comme maquettes/index-lancement.html, et le paywall de lancement comme maquettes/paywall-lancement.html
- Le pass saison affiché « bientôt », avec un bouton « être prévenu » qui garde l'email
- Un petit bandeau « on vient de lancer » avec un lien vers le journal

// 2. Les cas que tu dois obligatoirement gérer :
- Les fondateurs gardent leur prix, quoi qu'il arrive
- Vérifier de bout en bout un vrai paiement à 9 $
- Me faire une liste de vérification du jour J, point par point, avec le résultat

// 3. Explication pas à pas :
Ensuite, explique-moi quoi surveiller pendant la journée de lancement. En français simple, sans jargon.
```

## Hors code
- [ ] Écrire et programmer ton annonce (X, LinkedIn, email à ta liste et au journal)
- [ ] Répondre à chaque commentaire le jour même
- [ ] Post « boss vaincu » avec les chiffres du soir
