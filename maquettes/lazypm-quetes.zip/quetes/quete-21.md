# Quête #21 · Répondre vite

Section 3 · Préparer le lancement · environ 1 à 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Chaque problème signalé t'arrive avec tout le contexte, et la personne est prévenue quand c'est réglé.

**Test :** Un testeur signale un problème : tu reçois un email avec sa page, sa quête et son abonnement. Tu le marques « réglé », il est prévenu.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **CONTEXTE** · Un signalement → la page, la quête et l'abonnement de la personne
- [ ] **SUIVI** · Plusieurs signalements → nouveau, en cours, réglé
- [ ] **RÉGLÉ** · Passer à « réglé » → la personne reçoit un email
- [ ] **AIDE** · Les 5 questions qu'on te pose le plus → une page d'aide y répond

## Le piège d'expérience
Répondre par des phrases toutes faites. Au début, chaque réponse personnelle est un post que ton client peut partager.

## Ce qu'il te faut
- Une adresse email de support sur ton domaine

## Le prompt à coller dans Claude Code

```text
# QUÊTE #21 : RÉPONDRE VITE
Je veux ne jamais laisser un client sans réponse sur LazyPM.

// 1. Ce que je veux obtenir :
- Chaque signalement et chaque message m'arrivent par email, avec la page, la quête en cours et l'abonnement
- Une liste des signalements avec un statut : nouveau, en cours, réglé
- Quand je passe un signalement à « réglé », la personne reçoit un email court
- Une page d'aide avec les questions fréquentes

// 2. Les cas que tu dois obligatoirement gérer :
- Rien ne doit se perdre, même si je suis absent un jour
- L'email « réglé » doit être personnel, pas un message automatique froid

// 3. Explication pas à pas :
Ensuite, explique-moi comment ajouter une question à la page d'aide. En français simple, sans jargon.
```
