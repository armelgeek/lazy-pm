# Quête #22 · Écrire à chaque client

Section 4 · Écouter et ajuster · environ 1 h, plus les messages · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Une liste « à qui écrire » avec, pour chaque client, un message personnel prêt à copier.

**Test :** Tu copies le message pour Léa : il dit son prénom et sa quête. Tu l'envoies depuis ta boîte mail.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **PARTIS** · Les clients qui ont résilié → dans la liste, en premier
- [ ] **PERSONNEL** · Le message copié → avec le bon prénom et la bonne quête
- [ ] **SUIVI** · Un client à qui tu as écrit → marqué « écrit le… »
- [ ] **RÉPONSE** · Une réponse collée dans Plus tard → rattachée au bon client

## Le piège d'expérience
Envoyer un questionnaire. Une seule question ouverte obtient bien plus de réponses, et des vraies.

## Le prompt à coller dans Claude Code

```text
# QUÊTE #22 : ÉCRIRE À CHAQUE CLIENT
Je veux écrire à chacun de mes clients LazyPM.

// 1. Ce que je veux obtenir :
- Une liste des clients payants et de ceux partis ce mois-ci, avec leur prénom, leur quête et leur dernier check-in
- Pour chacun, un message à copier : « Salut Léa, tu es à la quête #14. C'est quoi le truc qui te manque le plus ? »
- Une case pour noter à qui j'ai déjà écrit

// 2. Les cas que tu dois obligatoirement gérer :
- Les clients partis apparaissent en premier
- Les réponses que je colle dans Plus tard sont rattachées au bon client

// 3. Explication pas à pas :
Ensuite, explique-moi comment coller les réponses pour qu'elles soient bien rangées. En français simple, sans jargon.
```

## Hors code
- [ ] Écrire à chaque client depuis ta propre boîte mail, en commençant par ceux qui sont partis
