# Quête #23 · Ranger les retours

Section 4 · Écouter et ajuster · environ 2 à 3 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Chaque réponse client est rangée avec l'idée qui lui ressemble. Plus tard se trie par nombre de demandes.

**Test :** Tu colles deux réponses qui disent la même chose avec des mots différents : elles finissent dans la même idée.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **MÊME IDÉE** · « Je veux du vertical » et « il faudrait du 9:16 » → la même idée
- [ ] **NOUVELLE** · Une réponse sans rapport → une nouvelle idée
- [ ] **DOUTE** · Une réponse ambiguë → dans « à ranger », pas rangée au hasard
- [ ] **CORRIGER** · Une citation mal rangée → tu la déplaces, les compteurs suivent

## Le piège d'expérience
Laisser l'IA fusionner des demandes proches mais différentes. Garde la correction à la main facile.

## Ce qu'il te faut
- La maquette maquettes/plus-tard.html

## Le prompt à coller dans Claude Code

```text
# QUÊTE #23 : RANGER LES RETOURS
Je veux que LazyPM range tout seul les retours de mes clients.

// 1. Ce que je veux obtenir :
- Chaque réponse collée est comparée aux idées existantes : rangée avec la plus proche, ou crée une nouvelle idée
- Chaque idée garde ses citations (qui, quoi, parti ou non) et son nombre de demandes
- Plus tard trié par nombre de demandes, la n°1 marquée « quête #29 », avec les citations dépliables comme dans maquettes/plus-tard.html

// 2. Les cas que tu dois obligatoirement gérer :
- En cas de doute, la réponse reste « à ranger »
- On peut déplacer une citation vers une autre idée

// 3. Explication pas à pas :
Ensuite, explique-moi comment l'IA décide que deux réponses parlent de la même chose. En français simple, sans jargon.
```
