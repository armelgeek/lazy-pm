# Quête #24 · Le pass saison et plusieurs projets

Section 4 · Écouter et ajuster · environ 3 à 4 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Le pass saison s'ouvre : 69 $ une fois pour 12 mois, jusqu'à 3 projets, avec sa garantie. On passe d'un projet à l'autre depuis le menu.

**Test :** Tu paies le pass avec une carte de test, puis tu crées un 2e projet : son chemin, ses quêtes et son Plus tard sont séparés du premier.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **PASS** · Un pass payé → 12 mois d'accès, puis la fin prévue et annoncée à l'avance
- [ ] **RIEN PERDU** · Les données d'avant → toutes dans le premier projet
- [ ] **SÉPARÉ** · Changer de projet → chemin, quêtes et notes changent
- [ ] **LIMITE MENSUEL** · Un abonné mensuel → un seul projet
- [ ] **LIMITE PASS** · Un pass saison → 3 projets, pas 4

## Le piège d'expérience
Faire le changement directement sur le vrai site. Demande de tester d'abord sur une copie.

## Le prompt à coller dans Claude Code

```text
# QUÊTE #24 : LE PASS SAISON ET PLUSIEURS PROJETS
J'ouvre le pass saison de LazyPM, avec plusieurs projets.

// 1. Ce que je veux obtenir :
- Le pass saison : un paiement unique de 69 $ qui donne 12 mois d'accès et jusqu'à 3 projets
- La garantie : si le client n'a rien lancé à sa quête #30, ou au bout des 12 mois, il peut demander à être remboursé. Montre-moi comment je le vérifie
- Chaque plan, quête, check-in et note appartient à un projet
- Le sélecteur de projet de la barre latérale (comme dans les maquettes) : liste, projet actif, « nouveau projet »
- 1 projet pour l'abonnement mensuel, 3 pour le pass saison, avec un message clair au-delà
- La série et le check-in sont par projet

// 2. Les cas que tu dois obligatoirement gérer :
- Aucune donnée existante ne doit être perdue
- Tester le changement sur une copie avant le vrai site

// 3. Explication pas à pas :
Ensuite, explique-moi comment on a testé sans risque pour les données de mes clients. En français simple, sans jargon.
```

## Hors code
- [ ] Écrire à tous ceux qui ont demandé à être prévenus de l'ouverture du pass
