# Quête #25 · Réduire l'abandon

Section 4 · Écouter et ajuster · environ 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Tu trouves l'étape qui perd le plus de monde, tu la répares, et les inactifs reçoivent un message pour revenir.

**Test :** Un compte inactif depuis 5 jours reçoit un seul email, qui mène au replanning.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **UNE FOIS** · 5 jours d'inactivité → un seul email, pas un par jour
- [ ] **DOUX** · Le message → propose de reprendre en plus petit, sans reproche
- [ ] **LIEN** · Le lien de l'email → ouvre le replanning
- [ ] **UN SEUL CHANGEMENT** · L'étape qui perd le plus → un changement à la fois

## Le piège d'expérience
Tout corriger à la fois. Un seul changement à la fois, sinon tu ne sais pas ce qui a marché.

## Le prompt à coller dans Claude Code

```text
# QUÊTE #25 : RÉDUIRE L'ABANDON
Je veux que moins de gens abandonnent LazyPM.

// 1. Ce que je veux obtenir :
- La liste des personnes inactives depuis 5 jours, avec leur dernière quête
- Un email de retour au 5e jour, une seule fois, qui propose de reprendre plus petit ou de replanifier
- Regarde avec moi mes chiffres : dis-moi quelle étape perd le plus de monde et propose 3 changements, du plus simple au plus long

// 2. Les cas que tu dois obligatoirement gérer :
- Jamais plus d'un email de retour par personne
- On ne fait qu'un seul changement ce soir

// 3. Explication pas à pas :
Ensuite, explique-moi quel chiffre surveiller pour savoir si le changement a marché. En français simple, sans jargon.
```
