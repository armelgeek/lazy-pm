# Quête #26 · Sans boss : tu écoutes

Section 4 · Écouter et ajuster · environ 2 h, sans code · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Pas de code ce soir. 5 conversations avec des clients pour choisir la demande de la quête #29.

**Test :** Tu as 5 pages de notes, écrites mot pour mot, et une demande qui revient au moins 3 fois.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **OUVERTES** · Tes questions → aucune à laquelle on répond par oui ou non
- [ ] **MOT POUR MOT** · Tes notes → les phrases exactes, pas ton résumé
- [ ] **RÉPÉTÉ** · La demande choisie → citée par au moins 3 personnes
- [ ] **SILENCE** · Pendant l'appel → tu parles moins que la personne

## Le piège d'expérience
Défendre ton produit pendant l'appel. Tu es là pour comprendre, pas pour convaincre.

## Le prompt à coller dans Claude Code

```text
# QUÊTE #26 : SANS BOSS : TU ÉCOUTES
Ce soir, pas de code : aide-moi à préparer 5 conversations avec mes clients.

// 1. Ce que je veux obtenir :
- 6 questions ouvertes pour un appel de 20 minutes, à partir de ma liste Plus tard et de mes check-ins
- Un modèle de prise de notes par appel : ce qu'il a essayé, ce qui l'a bloqué, ses mots exacts
- Après mes appels, une synthèse de ce qui revient au moins 2 fois

// 2. Les cas que tu dois obligatoirement gérer :
- Aucune question du genre « est-ce que tu aimerais… »
- La synthèse cite les mots des clients, pas les miens

// 3. Explication pas à pas :
Ensuite, explique-moi comment choisir la demande de la #29 à partir de la synthèse. En français simple, sans jargon.
```

## Hors code
- [ ] Faire les 5 appels
- [ ] Post du soir : ce que tu as appris, sans nommer personne
