# Quête #27 · Que les utilisateurs partagent

Section 4 · Écouter et ajuster · environ 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Après son check-in, un utilisateur peut partager sa soirée en un clic, avec une belle image de sa progression.

**Test :** Tu cliques « Partager ma soirée » : une image avec ta quête et ta série, et un texte prêt à coller sur X.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **IMAGE** · L'image partagée → lisible sur X, avec la quête, la série et la barre des 30
- [ ] **PRIVÉ** · La page publique d'un projet → désactivée tant qu'on ne l'active pas
- [ ] **TEXTE** · Le texte proposé → modifiable avant de copier
- [ ] **ORIGINE** · Quelqu'un qui arrive par un partage → tu le sais

## Le piège d'expérience
Rendre la page publique active par défaut. Beaucoup ne veulent pas montrer un projet pas fini.

## Ce qu'il te faut
- La maquette maquettes/celebration.html

## Le prompt à coller dans Claude Code

```text
# QUÊTE #27 : QUE LES UTILISATEURS PARTAGENT
Je veux que mes utilisateurs puissent faire leur propre build in public avec LazyPM.

// 1. Ce que je veux obtenir :
- Après un check-in, « Partager ma soirée » : une image avec le projet, la quête, la série et la barre des 30 quêtes, dans le style du site
- Un texte proposé sur le modèle du post du soir (jour, quête, fait, coincé), modifiable
- Une page publique optionnelle pour chaque projet, désactivée par défaut
- La page de célébration comme maquettes/celebration.html quand on bat un boss

// 2. Les cas que tu dois obligatoirement gérer :
- Rien n'est public sans l'accord de la personne
- Savoir combien de nouveaux utilisateurs viennent des partages

// 3. Explication pas à pas :
Ensuite, explique-moi comment voir combien d'inscriptions viennent des partages. En français simple, sans jargon.
```
