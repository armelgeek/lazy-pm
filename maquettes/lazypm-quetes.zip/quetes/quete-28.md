# Quête #28 · La saison 2 se prépare

Section 4 · Écouter et ajuster · environ 1 à 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Une page saison 2 avec sa liste d'attente, montrée aux clients qui approchent de la fin.

**Test :** Un client à la quête #25 voit l'encart saison 2 dans son chemin. Un client à la #10, non.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **MOMENT** · Avant la #25 → pas d'encart
- [ ] **PROMESSE** · La page → ne promet ni date ni contenu, seulement la liste d'attente
- [ ] **LIEN** · Le lien « Saison 2 » ajouté au bas de page → mène à la vraie page
- [ ] **LISTE** · Une inscription → une confirmation

## Le piège d'expérience
Construire la saison 2 maintenant. Une liste d'attente suffit : tu construiras ce que ses inscrits demandent.

## Le prompt à coller dans Claude Code

```text
# QUÊTE #28 : LA SAISON 2 SE PRÉPARE
Je veux préparer la saison 2 de LazyPM.

// 1. Ce que je veux obtenir :
- Une page saison 2 : passer de 15 à 100 clients sans que les coûts explosent, avec une liste d'attente
- Un encart saison 2 dans le chemin à partir de la quête #25
- Un lien « Saison 2 » dans le bas de page

// 2. Les cas que tu dois obligatoirement gérer :
- L'encart n'apparaît pas avant la #25
- Ne promettre ni date ni contenu : la saison 2 se construira avec les inscrits

// 3. Explication pas à pas :
Ensuite, explique-moi comment voir la liste d'attente de la saison 2. En français simple, sans jargon.
```
