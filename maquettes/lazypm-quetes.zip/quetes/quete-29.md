# Quête #29 · Livrer la demande n°1

Section 4 · Écouter et ajuster · environ 4 à 6 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** La demande n°1 de tes clients est en ligne, dans sa plus petite version utile, et chaque client qui l'avait demandée est prévenu.

**Test :** Chaque client qui l'avait demandée reçoit un message qui cite ce qu'il avait dit.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **PETIT** · La version livrée → la plus petite qui répond aux citations
- [ ] **CITATIONS** · Chaque citation de la demande → une réponse, ou une raison claire
- [ ] **PRÉVENUS** · Chaque client concerné → un message personnel
- [ ] **LIVRÉE** · L'idée dans Plus tard → marquée « livrée »

## Le piège d'expérience
Livrer la version complète dont tu rêves. Livre la plus petite qui répond aux citations, puis écoute encore.

## Le prompt à coller dans Claude Code

```text
# QUÊTE #29 : LIVRER LA DEMANDE N°1
Je vais livrer la demande n°1 de mes clients. Je te colle la demande, les citations et mes notes d'appels.

// 1. Ce que je veux obtenir :
- La plus petite version qui répond vraiment aux citations, et ce qu'on laisse de côté pour l'instant
- Découpée en étapes livrables séparément, on commence par la première ce soir
- Une fois en ligne : la liste des clients qui l'avaient demandée, avec un message personnel à copier pour chacun
- L'idée marquée « livrée » dans Plus tard

// 2. Les cas que tu dois obligatoirement gérer :
- Ne rien construire que personne n'a demandé
- Chaque message cite les mots du client

// 3. Explication pas à pas :
Ensuite, explique-moi ce qu'on a laissé de côté, pour que je le note dans Plus tard. En français simple, sans jargon.
```

## Hors code
- [ ] Écrire à chaque client concerné
- [ ] Post : « vous l'avez demandé, c'est en ligne »
