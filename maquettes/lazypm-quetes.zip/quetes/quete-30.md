# Quête #30 · Le bilan de saison

Section 4 · Écouter et ajuster · environ 2 h · +20 XP

## 01 · Le résultat & le test de vérité
**À construire :** Un bilan public avec les vrais chiffres, ta promesse publique vérifiée, les demandes de garantie traitées, et la suite décidée.

**Test :** Chaque chiffre de ton bilan se retrouve dans ta page de suivi, et ta promesse publique est vérifiée noir sur blanc.

## 02 · La checklist de test : les cas que tu oublies
- [ ] **VRAIS CHIFFRES** · Chaque chiffre du bilan → vérifiable
- [ ] **PROMESSE** · Pas de lancement ni de premier client pour toi → tous les pass saison remboursés, comme promis
- [ ] **GARANTIE** · Une demande de remboursement d'un client → traitée selon la règle de la #24
- [ ] **RATÉS** · Ce qui n'a pas marché → dans le bilan aussi
- [ ] **MERCI** · Tes premiers fondateurs → un message personnel

## Le piège d'expérience
Cacher les chiffres décevants. Ton journal a de la valeur parce qu'il dit tout, y compris à la fin.

## Le prompt à coller dans Claude Code

```text
# QUÊTE #30 : LE BILAN DE SAISON
C'est la dernière quête de la saison de LazyPM.

// 1. Ce que je veux obtenir :
- Le bilan en chiffres : jours, quêtes faites, soirs sans code, heures, clients payants, revenu, coût IA, ce qu'il reste
- La vérification de ma promesse publique : ai-je lancé LazyPM et trouvé un premier client payant ? Si non, tous les pass saison sont à rembourser
- Les demandes de garantie des clients reçues, avec pour chacune la vérification et le remboursement prêt
- Un premier jet du bilan public pour le journal : ce qui a marché, ce qui a raté, la suite

// 2. Les cas que tu dois obligatoirement gérer :
- Aucun chiffre enjolivé
- Aucun remboursement dû oublié

// 3. Explication pas à pas :
Ensuite, explique-moi comment faire les remboursements. En français simple, sans jargon.
```

## Hors code
- [ ] Publier le bilan partout
- [ ] Remercier personnellement tes premiers fondateurs
